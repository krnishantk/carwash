import React, { Component } from 'react'
import axios from 'axios'
import { Redirect } from 'react-router-dom'

class SignUpForm extends Component {

   
    constructor(props) {
        super(props)

        this.state = {
            firstName:'',
            lastName:'',
            email:'',
            phone:'',
            userId:'',
            password:'',
            role:'Customer',
            city:''
        }
    }

    changeHandler = (e) => {
        this.setState({[e.target.name]: e.target.value})
    }

    submitHandler = e => {
        e.preventDefault()
        console.log(this.state)
        axios
            .post('http://localhost:9091/user', this.state)
            .then( response => {
                console.log(response.status)
                alert(response.data.msg)
                if (response.status == 200) {
                        this.setState({ success: true });
                } 
            })
            .catch(error => {
                console.log(error)
            })
    }

    render() {
        if (this.state.success) {
            return <Redirect to =  "/" />;
          }
        const { firstName, lastName, email, phone, userId, password, role, city } = this.state
        return (
            <div className="forms23-block-hny">
			<div className="wrapper">
				<div className="d-grid forms23-grids">
					<div className="form23">
						<div className="main-bg">
							<h6 className="sec-one">On Demand Car Wash Service</h6>
							<div className="speci-login first-look">
								<img src="00aimgaaa" alt="" className="img-responsive" />
							</div>
						</div>
						<div className="bottom-content">
                        <h4>SIGN UP</h4>
                <form onSubmit={this.submitHandler}>
                    <br></br>
                    <table>
                        <tr>
                            <td>
                            <input type="text" required="required" classname="input-form" name="firstName" placeholder="First Name" value={firstName} onChange={this.changeHandler} />
                            </td>
                            <td>
                            <input type="text" required="required" classname="input-form" name="lastName" placeholder="Last Name" value={lastName} onChange={this.changeHandler} />
                            </td>
                        </tr> <tr>
                            <td>
                            <input type="text" required="required" name="userId" placeholder="UserId" value={userId} onChange={this.changeHandler} />
                            </td>
                            <td>
                            <input type="text" required="required" name="email" placeholder="Email Id" value={email} onChange={this.changeHandler} />
                            </td>
                        </tr> <tr>
                            <td>
                            <input type="password" required="required"  name="password" placeholder="Password" value={password} onChange={this.changeHandler}  />
                            </td>
                            <td>
                            <input type="text" required="required" name="phone" placeholder="Phone Number" value={phone} onChange={this.changeHandler} />   
                            </td>
                        </tr>
                        <tr>
                            <td>
                            <input type="text" required="required" name="city" placeholder="City Name" value={city} onChange={this.changeHandler} />
                            </td>
                        </tr>
                    </table>
                    <br></br>
                    <div>
                        <button type="submit" className="login login-submit">Submit</button>
                    </div>
                </form>
                <div className="login-help">
                    <br></br>
                    • <a href="/">Already a member ?</a>
                </div>
						</div>
					</div>
				</div>
			</div>
		</div>
        )
    }
}

export default SignUpForm