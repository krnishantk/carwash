import React, { Component } from 'react'
import { Link, Redirect } from 'react-router-dom'
import axios from 'axios'
import { Helmet } from 'react-helmet';
import Page from './Page';
import './admin.css';
import Logo from './Logo'
import AdminOption from './AdminOption'


class AddService extends Component {
    constructor(props) {
        super(props)
        const token = localStorage.getItem("token")

        let loggedIn = true
        if(token == null){
            loggedIn = false
        }

        this.state = {
            loggedIn,
            packageName:'',
            price:'',
            discription:''
        }
    }

    changeHandler = (e) => {
        this.setState({[e.target.name]: e.target.value})
    }

    submitHandler = e => {
        e.preventDefault()
        console.log(this.state)
        axios
            .post('http://localhost:9092/package', this.state)
            .then( response => {
                console.log(response.status)
                alert(response.data.msg)
                if (response.status == 200) {
                        this.setState({ success: true });
                } 
            })
            .catch(error => {
                console.log(error)
            })
    }


    render() {

        if(this.state.loggedIn === false){
            return <Redirect to ="/" />
        }
        const userId = localStorage.getItem("userId");
        const { packageName, price, discription  } = this.state

        return(
            <div>
               
               <AdminOption />
               <Logo />

            <div className="adminAddUser"> 
            <Page title="Add New Service">
                <Helmet>
                <title>Add New Service</title>
                </Helmet>

                <form onSubmit={this.submitHandler}>
                    <br></br>
                    <table>
                        <tr>
                            <td>Service/Package Name </td>
                            <td className="adminAddUserTable">:</td>
                            <td><input type="text" required="required" name="packageName" placeholder="Service Name" value={packageName} onChange={this.changeHandler} /></td>
                        </tr>
                        <tr>
                            <td>Price </td>
                            <td className="adminAddUserTable">:</td>
                            <td><input type="text" required="required" classname="input-form" name="price" placeholder="Price" value={price} onChange={this.changeHandler} /></td>
                        </tr>
                        <tr>
                            <td>Discription </td>
                            <td className="adminAddUserTable">:</td>
                            <td><input type="text" required="required" classname="input-form" name="discription" placeholder="Discription" value={discription} onChange={this.changeHandler} /></td>
                        </tr>
                    </table>
                    <br></br>
                    <div>
                        <button type="submit" className="login login-submit">Submit</button>
                    </div>
                    <br></br>
                    <div>
                        <Link to="/adminServices"> Back</Link>
                    </div>
                </form>
            </Page>
            </div>
            </div>
        )
    }
}

export default AddService