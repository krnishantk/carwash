import React from 'react';
import { Table, Menu, Icon } from 'semantic-ui-react';
import { Link, Redirect } from 'react-router-dom'
import { get } from 'axios';
import times from 'lodash.times';
import { Helmet } from 'react-helmet';
import Page from './Page';
import './admin.css';
import Logo from './Logo'
import axios from 'axios'
import AdminOption from './AdminOption'
import {Button} from 'react-bootstrap'

const TOTAL_PER_PAGE = 10;

class CarDetails extends React.Component {
  constructor(props) {
    super(props);

    const token = localStorage.getItem("token")

        let loggedIn = true
        if(token == null){
            loggedIn = false
        }

        this.state = {
            loggedIn,
      carTypes: [],
      page: 0,
      totalPages: 0,
    };
    this.incrementPage = this.incrementPage.bind(this);
    this.decrementPage = this.decrementPage.bind(this);
    this.setPage = this.setPage.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
  }

  componentDidMount() {
    this.getCarTypeDetails();
  }

  componentWillReceiveProps({ location = {} }) {
    if (location.pathname === '/users' && location.pathname !== this.props.location.pathname) {
      this.getUsers();
    }
  }

  getCarTypeEnableDisable(carTypeName){
      console.log(carTypeName)
    axios
    .put('http://localhost:9093/carType/activeInActive/'+carTypeName, this.state)
    .then( response => {
        alert(response.data.msg) 
        this.getCarTypeDetails()
    })
    .catch(error => {
        console.log(error)
    })
  }

  getCarTypeDetails() {
    get('http://localhost:9093/carType/getAll')
      .then(({ data }) => {
          console.log(data)
        const { carTypes } = data;
        const totalPages = Math.ceil(8 / TOTAL_PER_PAGE);

        this.setState({
            carTypes: data,
          page: 0,
          totalPages,
        });
      });
  }

  setPage(page) {
    return () => {
      this.setState({ page });
    };
  }

  decrementPage() {
    const { page } = this.state;

    this.setState({ page: page - 1 });
  }

  incrementPage() {
    const { page } = this.state;

    this.setState({ page: page + 1 });
  }

  handleDelete(userId) {
    const { carTypes } = this.state;

    this.setState({
        carTypes: carTypes.filter(u => u.id !== userId),
    });
  }

  render() {

    if(this.state.loggedIn === false){
      return <Redirect to ="/" />
  }
  const userId = localStorage.getItem("userId");
    const { carTypes, page, totalPages } = this.state;
    const startIndex = page * TOTAL_PER_PAGE;

    return (
      <div>

              <AdminOption />
               <Logo />

        <div className="userStyle">
      <Page title="Car Type Details">
        <Helmet>
          <title>Car Type Details</title>
        </Helmet>

        <Table celled striped>
          <Table.Header>
            <Table.Row>
              <Table.HeaderCell>Car Type</Table.HeaderCell>
              <Table.HeaderCell>Car Details</Table.HeaderCell>
              <Table.HeaderCell>Active</Table.HeaderCell>
              <Table.HeaderCell>Action</Table.HeaderCell>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {carTypes.slice(startIndex, startIndex + TOTAL_PER_PAGE).map(carType =>
              (<Table.Row key={carType.id}>
                <Table.Cell>{carType.carTypeName}</Table.Cell>
                <Table.Cell>{carType.carTypeDetails} </Table.Cell>
                <Table.Cell>

                {(() => {
                      switch (''+carType.isActive) {
                        case "true":   return "Yes"
                        case "false":  return "No"
                      }
                })()}

                </Table.Cell>
                <Table.Cell>
                {(() => {
                    switch (''+carType.isActive) {
                      case "true": 
                        return <Button variant="outline-danger" onClick={() => this.getCarTypeEnableDisable(carType.carTypeName)}>InActive</Button>
                     case "false":  
                        return <Button variant="outline-info" onClick={() => this.getCarTypeEnableDisable(carType.carTypeName)}>Active</Button>
                    }
                })()}
                        </Table.Cell>
              </Table.Row>),
            )}
          </Table.Body>
          <Table.Footer>
            <Table.Row>
              <Table.HeaderCell colSpan={6}>
                <Menu floated="right" pagination>
                  {page !== 0 && <Menu.Item as="a" icon onClick={this.decrementPage}>
                    <Icon name="left chevron" />
                  </Menu.Item>}
                  {times(totalPages, n =>
                    (<Menu.Item as="a" key={n} active={n === page} onClick={this.setPage(n)}>
                      {n + 1}
                    </Menu.Item>),
                  )}
                  {page !== (totalPages - 1) && <Menu.Item as="a" icon onClick={this.incrementPage}>
                    <Icon name="right chevron" />
                  </Menu.Item>}
                </Menu>
              </Table.HeaderCell>
            </Table.Row>
          </Table.Footer>
        </Table>
        <Link to="/adminAddService"> Add New</Link>
      </Page>
      </div>
      </div>
    );
  }
}

export default CarDetails;
